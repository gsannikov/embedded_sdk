#!/bin/bash
# ==============================================================================
# build.sh CMake/Ninja Build Script for MMG Project
#
# Initializes a clean build directory, configures the CMake
# project using the Ninja build system and an optional toolchain file,
# and compiles the project using all available cores.
#
# Usage:
#   ./build.sh [BuildType]
#
# Arguments:
#   BuildType (optional)  Specify CMake build type: Release (default), Debug, etc.
#
# Environment Variables:
#   None required.
#
# Requirements:
#   - CMake
#   - Ninja (install with `sudo dnf install ninja-build` or `apt install ninja-build`)
#
# Notes:
#   - Adjust SOURCE_ROOT_PATH if your source tree is elsewhere.
#   - Existing build directory will be deleted before each run.
# ==============================================================================


# Optional: Allow build type override via env or argument
BUILD_TYPE=${1:-Release}
BUILD_DIR=build
TOOLCHAIN_FILE=cmake/toolchain.cmake
SOURCES_ROOT_PATH=/home/emichael/projects/mmg_proj1_repo/sources

# Clean old build
rm -rf "${BUILD_DIR}"
mkdir -p "${BUILD_DIR}"
cd "${BUILD_DIR}"

# Run CMake with Ninja generator
cmake .. \
  -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE=../${TOOLCHAIN_FILE} \
  -DCMAKE_BUILD_TYPE=${BUILD_TYPE} \
  -DSOURCES_ROOT_PATH=${SOURCES_ROOT_PATH} \
  -DMMG=1 \
  -DDO_COMPILE_INFRA=1 \
  -DZEPHYR_BUILD=1

# Build using ninja
ninja -j$(nproc)
