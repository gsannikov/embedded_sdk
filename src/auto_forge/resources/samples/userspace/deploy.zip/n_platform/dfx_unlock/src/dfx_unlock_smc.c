/***********************************************************************
 * Copyright(c) 2018 - 2021 Intel Corporation
 *
 * For licensing information, see the file 'LICENSE' in the root folder
 * *********************************************************************/
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

#include "dfx_unlock_smc.h"
#include "syscon_lib_access.h"

int dfx_unlock_smc(uint8_t unlock_type, uint32_t *password, uint32_t password_size_bytes)
{
	int fd, ret = 0;
	int status = 0;
	int password_size_dwords = 0;
	struct mev_imc_smc_desc desc = {0};

	/*TODO : use SMC library instead*/
	fd = open("/dev/mev_imc_smc", O_RDWR);
	if (fd < 0) {
		printf("File open error\n");
		return -FILE_OPEN_ERROR;
	}

	password_size_dwords = password_size_bytes / 4;
	if (SMC_MAX_INPUT < password_size_dwords) {
		printf("SMC Cannot Support Provided Password Size!");
		close(fd);
		return -SMC_UNSUPPORTED_PWD_SIZE;
	}

	desc.in_params[0] = unlock_type;
	for (int i = 0; i < password_size_dwords / 2; i++)
		/*Align password dwords into 64bit lsb and msb chunks*/
		desc.in_params[i + 1] = (uint64_t)password[i * 2 + 1] << 32 | password[i * 2];

	desc.in_params_num = SMC_MAX_INPUT;
	desc.out_params_num = SMC_MAX_OUTPUT;

	desc.smc_fid = MEV_IMC_SMC_DFX;

	/*calling secure monitor in ATF*/
	ret = ioctl(fd, MEV_IMC_SMC_CALL, &desc);
	if (ret)
		printf("IOTCL failed\n");

	status = (uint32_t)desc.out_params[0];
	close(fd);

	/*zeroes desc struct*/
	memset(&desc, 0, sizeof(desc));

	/*zeroes passwords*/
	for (int i = 0; i < password_size_dwords; i++)
		password[i] = 0;

	return status;
}
